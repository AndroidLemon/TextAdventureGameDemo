#pragma once
#ifndef FIGHTER_H
#define FIGHTER_H

#include "Character.h"
class Fighter : public Character
{
public:
	Fighter();
	~Fighter();

	void attack(Character* enemy);
	void defend();
	void heal();
};

#endif // FIGHTER_H
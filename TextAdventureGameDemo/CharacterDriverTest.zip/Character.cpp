#include "Character.h"


Character::Character()
{
}


Character::~Character()
{
	cout << name << " has been slain in battle! \n";
}

void Character::setMaxHP(int hp)
{
	maxHP = hp;
}

void Character::setHP(int hp)
{
	hitPoints = hp;
}

void Character::setStrength(int str)
{
	strength = str;
}

void Character::setDefense(int def)
{
	defense = def;
}

void Character::setMagic(int mag)
{
	magic = mag;
}

void Character::setResistance(int res)
{
	resistance = res;
}

void Character::setLuck(int lk)
{
	luck = lk;
}

void Character::setFatigued(bool f)
{
	fatigued = f;
}

void Character::setDefending(bool d)
{
	defending = d;
}

void Character::printCharacter()
{
	cout
		<< "Name: " << name << endl
		<< "Max HP: " << getHP() << endl
		<< "Strength: " << getStrength() << endl
		<< "Defense: " << getDefense() << endl
		<< "Magic: " << getMagic() << endl
		<< "Resistance: " << getResistance() << endl
		<< "Luck: " << getLucky() << endl;
}

void groupAttack(Character* group)
{
	int tempAttack = 0;

	for (int i = 0; i < 3 ; i++) {

		tempAttack += (group[i].getStrength() + group[i].getMagic());
	}
}

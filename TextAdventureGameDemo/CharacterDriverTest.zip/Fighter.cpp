#include "Fighter.h"

Fighter::Fighter() //Defautl constructor is a randomly generated fighter for testing. Still tweaking stat
{
	name = "Ogma";
	setMaxHP(rand() % 100);
	setHP(maxHP);
	setStrength(rand() % 50);
	setDefense(rand() % 50);
	setLuck(rand() % 50);
	setMagic(rand() % 50);
	setResistance(rand() % 50);
}


Fighter::~Fighter()
{
}

void Fighter::attack(Character * enemy)
{
	int damageDone = this->getStrength() - enemy->getDefense();
	if (enemy->isDefending) {
		damageDone -= (damageDone * .25);
	}

	if (damageDone < 0) {
		damageDone = 0;
	}

	enemy->setHP(enemy->getHP() - damageDone);
	if (enemy->getHP() <= 0)
		delete enemy;
	return;
}

void Fighter::defend() //Sets defending ststus to true, allowing for a damage reduction this turn.
{
	setDefending(true);
}

void Fighter::heal() //Character rests, healing for 30%.
{
	hitPoints += (maxHP * .30);
	if (hitPoints > maxHP)
		hitPoints = maxHP;
}

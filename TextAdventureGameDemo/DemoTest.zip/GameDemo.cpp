//This is a simple turn based battle game 
//
// Albert Jackson
// 5/10/18

#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include "Character.h"
#include "Fighter.h"
#include "Mage.h"
#include "Monster.h"
#include "Rogue.h"

using namespace std;

void PlayerTakeTurn(Character* player, vector <Character*> &enemies);
void enemyTakeTurn(Character* monster, vector <Character*> &enemies);
bool encounter(vector <Character*> &party, vector <Character*> &enemies);
bool checkPartyStatus(vector <Character*> &group);

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
	return dynamic_cast<const Base*>(ptr) != nullptr;
}

/*UPDATE NOTES!

1.) Program takes turns now! And furthermore, the monsters can randomly select their own actions!
2.) Dynamic Casting works! I realize that it's probably poor design, but I'm honestly super excited to see that it CAN work.
3.) Next I need to add the friend function for the group attack and overload the << operator for the ToString()
4.) Also going to overload the ++ operator for level ups (which will just be a series of small random stat boosts).
5.) Also gonna add static functions for additional "Special skills". 

*/


int main() {

	srand(time(0));

	vector <Character*> party;
	vector <Character*> enemies;

	enemies.push_back(new Monster());
	enemies.push_back(new Monster());

	party.push_back(new Rogue());
	party.push_back(new Fighter());
	party.push_back(new Mage());
	

	if (encounter(party, enemies)) {
		cout << "\nThe battle is won!\n\n";
	}
	else if (!encounter(party, enemies)) {
		cout << "\nYou're dead!\n\n";
	}

	system("pause");
	return 0;
}

void PlayerTakeTurn(Character* player, vector <Character*> &enemies) {
	if (!player->isAlive())
	{
		return;
	}

	if (player->isDefending()) {
		cout << player->getName() << " no longer has their defenses raised.\n";
		player->setDefending(false);
	}
	if (player->isFatigued()) {
		cout << player->getName() << "cannot move this turn due to fatigue! \n";
		player->setFatigued(false);
		return;
	}

	cout << "\nWhat will " << player->getName() << " do?\n";

	if (dynamic_cast<Fighter*>(player) != nullptr) {
		dynamic_cast<Fighter*>(player)->options(enemies);
	}

	else if (dynamic_cast<Mage*>(player) != nullptr) {
		dynamic_cast<Mage*>(player)->options(enemies);
	}

	else if (dynamic_cast<Rogue*>(player) != nullptr)
	{
		dynamic_cast<Rogue*>(player)->options(enemies);
	}
}

void enemyTakeTurn(Character* monster, vector <Character*> &enemies) {
	if (!monster->isAlive()) {
		return;
	}

	if (monster->isDefending()) {
		cout << monster->getName() << " no longer has their defenses raised.\n";
		monster->setDefending(false);
	}

	switch (1 + rand() % 2)
	{
	case Monster::monsterChoices::attacks:
		monster->attack(enemies[rand() % (enemies.size())]);
		break;

	case Monster::monsterChoices::defense:
		monster->defend();
		break;
	case Monster::monsterChoices::health:
		monster->heal();

	default:
		cout << "Not a choice"; //Shouldn't actually trigger, but just a debugging check.
		break;
	}
}

bool encounter(vector <Character*> &party, vector <Character*> &enemies) {
	bool partyAlive = true;
	bool enemiesAlive = true;
	int i = 0;
	int j = 0;

	while (partyAlive && enemiesAlive) {
		if (i == party.size()) {
			i = 0;
		}
		PlayerTakeTurn(party[i], enemies);
		enemiesAlive = checkPartyStatus(enemies);
		i++;

		if (j == enemies.size()) {
			j = 0;
		}
		enemyTakeTurn(enemies[j], party);
		partyAlive = checkPartyStatus(party);
		j++;
	}

	if (enemiesAlive) {
		return false; //You lose!
	}
	else if (partyAlive) {
		return true; // You Win!
	}
}

bool checkPartyStatus(vector <Character*> &group) {

	int deadMemberCount = 0;
	//int deadMonsterCount = 0;

	for (int i = 0; i < group.size(); i++) {
		//cout << endl << endl << group[i]->isAlive() << endl << endl;
		if (!group[i]->isAlive()) {
			deadMemberCount++;
		}
	}

	if (deadMemberCount == group.size()) {
		return false; //All party members are dead.
	}
	else if (deadMemberCount < group.size()) {
		return true; //At least one member is still alive, so battle continues.
	}
}
#include "Character.h"


Character::Character()
{
	playerPTR = this;
}


Character::~Character()
{
	//cout << name << " has been slain in battle! \n";
	//delete playerPTR;
	//playerPTR = nullptr;
	//cout << "Goodbye cruel world.";
}

Character * Character::targetChar(vector<Character*> *enemies)
{
	int choice;
	for (int i = 0; i < enemies->size(); i++) {
		cout
			<< i + 1 << ") " << (*enemies)[i]->getName() << endl;
	}

	cin >> choice;
	return (*enemies)[choice - 1];
}

void Character::setMaxHP(int hp)
{
	maxHP = hp;
}

void Character::setHP(int hp)
{
	hitPoints = hp;
}

void Character::setStrength(int str)
{
	strength = str;
}

void Character::setDefense(int def)
{
	defense = def;
}

void Character::setMagic(int mag)
{
	magic = mag;
}

void Character::setResistance(int res)
{
	resistance = res;
}

void Character::setLuck(int lk)
{
	luck = lk;
}

void Character::setLife(bool l)
{
	living = l;
}

void Character::setFatigued(bool f)
{
	fatigued = f;
}

void Character::setDefending(bool d)
{
	defending = d;
}

void Character::printCharacter()
{
	cout
		<< "Name: " << name << endl
		<< "Max HP: " << getHP() << endl
		<< "Strength: " << getStrength() << endl
		<< "Defense: " << getDefense() << endl
		<< "Magic: " << getMagic() << endl
		<< "Resistance: " << getResistance() << endl
		<< "Luck: " << getLucky() << endl;
}

void Character::heal()
{
	cout << name << " is taking a breather, restoring HP!\n";
	cout << hitPoints << "HP -> ";
	hitPoints += (maxHP * .30);
	if (hitPoints > maxHP)
		hitPoints = maxHP;
	cout << hitPoints << "HP. \n\n";
}

void Character::defend()
{
	cout << name << " raises their defenses! \n";
	setDefending(true);
}

bool Character::isCriticalHit(int luck)
{
	{
		if (luck >= (1 + rand() % 200))
			return 1;
		else
			return 0;
	}
}

void groupAttack(Character* group)
{
	int tempAttack = 0;

	for (int i = 0; i < 3 ; i++) {

		tempAttack += (group[i].getStrength() + group[i].getMagic());
	}
}

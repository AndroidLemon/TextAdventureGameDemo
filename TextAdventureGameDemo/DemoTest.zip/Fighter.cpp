#include "Fighter.h"

Fighter::Fighter() //Defautl constructor is a randomly generated fighter for testing. Still tweaking stat
{
	name = "Ogma";
	setMaxHP(rand() % 200 + 100);
	setHP(maxHP);
	setStrength(35 + rand() % 15);
	setDefense(30 + rand() % 20);
	setLuck(10 + rand() % 50);
	setMagic(10 + rand() % 30);
	setResistance(15 + rand() % 30);
}


Fighter::~Fighter()
{
}

void Fighter::attack(Character * enemy, int damageFactor)
{
	//int critRate = ((luck + 1) / 256) * 100;

	if (!enemy->isAlive()) {
		cout << "Enemy is already dead!\n";
		return;
	}

	int damageDone = 5 * (this->getStrength() - (.5* enemy->getDefense())) / damageFactor;

	if (enemy->isDefending()) {
		damageDone -= (damageDone * .25);
	}
	if (isCriticalHit(luck)) {
		cout << "Critical strike! \n";
		damageDone *= 2;
	}

	if (damageDone <= 0) {
		damageDone = 0;
	}

	enemy->setHP(enemy->getHP() - damageDone);
	cout << damageDone << " damage was dealt to " << enemy->getName() << "!\n";
	if (enemy->getHP() <= 0) {
		cout << enemy->getName() << " has been slain in battle! \n";
		enemy->setLife(false);
	}
	return;
}

//void Fighter::defend() //Sets defending ststus to true, allowing for a damage reduction this turn.
//{
//	setDefending(true);
//}

void Fighter::options(vector <Character*> &enemies)
{
	int choice;
	cout
		<< "Available actions: \n"
		<< "1.) Attack \n"
		<< "2.) Defend \n"
		<< "3.) Treat wounds \n";

	cin >> choice;
	switch (choice) {
	case 1:
		cout << "Which enemy will you attack? ";
		attack(targetChar(&enemies));
		break;
	case 2:
		defend();
		break;
	case 3:
		heal();
		break;
	}

	return;
}

/*void Fighter::heal() //Character rests, healing for 30%.
{
	hitPoints += (maxHP * .30);
	if (hitPoints > maxHP)
		hitPoints = maxHP;
}*/

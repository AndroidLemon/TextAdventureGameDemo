#include "Monster.h"



Monster::Monster()
{
	name = "Chocobo";
	setMaxHP(rand() % 200 + 100);
	setHP(maxHP);
	setStrength(35 + rand() % 15);
	setDefense(30 + rand() % 20);
	setLuck(10 + rand() % 50);
	setMagic(10 + rand() % 30);
	setResistance(15 + rand() % 30);
}


Monster::~Monster()
{
}

void Monster::attack(Character * enemy, int damageFactor)
{
	cout << name << " is attacking!\n";

	if (!enemy->isAlive()) {
		cout << enemy->getName() << " is already dead!\n" << name << " feasts on the remains!\n";
		heal();
		return;
	}

	int damageDone = 5 * (this->getStrength() - (.5* enemy->getDefense())) / damageFactor;

	if (enemy->isDefending()) {
		damageDone -= (damageDone * .25);
	}
	if (isCriticalHit(luck)) {
		cout << "Critical strike! \n";
		damageDone *= 2;
	}

	if (damageDone <= 0) {
		damageDone = 0;
	}

	enemy->setHP(enemy->getHP() - damageDone);
	cout << damageDone << " damage was dealt to " << enemy->getName() << "!\n";
	if (enemy->getHP() <= 0) {
		cout << enemy->getName() << " has been slain in battle! \n";
		enemy->setLife(false);
	}
	return;
}

void Monster::options(vector <Character*> &enemies)
{
}
